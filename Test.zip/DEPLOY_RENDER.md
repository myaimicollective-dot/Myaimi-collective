# Deploy on Render (Bitbucket)

## 1) Upload this project to Bitbucket
Your repo root must contain:
- render.yaml
- backend/
- frontend/

## 2) Create from Blueprint
Render Dashboard → New + → **Blueprint**
Select your Bitbucket repo → Continue.

Render will auto-create:
- Postgres DB
- Backend web service
- Frontend static site

## 3) Paste Stripe secrets (the only secrets you must add)
Render → myaimi-backend → Environment:
- STRIPE_SECRET_KEY (Stripe → Developers → API keys)
- STRIPE_WEBHOOK_SECRET (Stripe → Developers → Webhooks)

## 4) Create Stripe webhook
Stripe → Developers → Webhooks → Add endpoint:
- URL: https://<your-backend>.onrender.com/api/stripe/webhook
- Event: checkout.session.completed

## 5) Create your Admin user (once)
Render → myaimi-backend → Shell:
- node src/scripts/createAdmin.js your@email.com yourPassword
