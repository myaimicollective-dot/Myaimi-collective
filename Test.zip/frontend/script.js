// ============================
// Myaimi Collective (demo store)
// Fully functional demo:
/// - Click products -> product page
/// - Add to basket -> cart badge updates + cart page
/// - Hero slider dots clickable + auto rotate
// ============================

const STORE_KEY = "myaimi_cart_v1";

const BASE_PRODUCTS = [
  {id:"p1",  name:"Satin Midi Dress",           price:32.99, img:"assets/p1.jpg",  category:"women",  tags:["dress"], sale:false},
  {id:"p2",  name:"Gold Buckle Top",            price:22.99, img:"assets/p2.jpg",  category:"women",  tags:["top"],  sale:true,  was:27.99},
  {id:"p3",  name:"Luxe Tracksuit Set",         price:29.99, img:"assets/p3.jpg",  category:"women",  tags:["tracksuit"], sale:false},
  {id:"p4",  name:"Two Piece Co-ord",           price:34.99, img:"assets/p4.jpg",  category:"women",  tags:["set"], sale:true,  was:44.99},
  {id:"p5",  name:"Kids Bow Dress",             price:18.99, img:"assets/p5.jpg",  category:"kids",   tags:["dress"], sale:false},
  {id:"p6",  name:"Kids Tracksuit Set",         price:19.99, img:"assets/p6.jpg",  category:"kids",   tags:["tracksuit"], sale:true, was:24.99},
  {id:"p7",  name:"Baby Romper Set",            price:16.99, img:"assets/p7.jpg",  category:"babies", tags:["romper"], sale:false},
  {id:"p8",  name:"Baby Soft Knit",             price:15.99, img:"assets/p8.jpg",  category:"babies", tags:["knit"], sale:true,  was:19.99},
  {id:"p9",  name:"Evening Mini Dress",         price:36.99, img:"assets/p9.jpg",  category:"women",  tags:["dress"], sale:false},
  {id:"p10", name:"Premium Blazer",             price:39.99, img:"assets/p10.jpg", category:"women",  tags:["outerwear"], sale:false},
  {id:"p11", name:"Kids Occasion Dress",        price:22.99, img:"assets/p11.jpg", category:"kids",   tags:["dress"], sale:true,  was:28.99},
  {id:"p12", name:"Baby Sleepsuit",             price:12.99, img:"assets/p12.jpg", category:"babies", tags:["sleep"], sale:false},
];

const PRODUCTS_KEY = "myaimi_products_v1";
function loadProducts(){
  const custom = readJSON(PRODUCTS_KEY, null);
  return Array.isArray(custom) && custom.length ? custom : BASE_PRODUCTS;
}
let PRODUCTS = loadProducts();
// Ensure each product has a short description
PRODUCTS = PRODUCTS.map(p => ({...p, desc: p.desc || (p.tags?.includes('dress') ? 'Premium dress • Boutique fit' : p.tags?.includes('tracksuit') ? 'Soft luxe tracksuit set' : 'Boutique essential') }));


function money(n){ return "£" + n.toFixed(2); }

// ---------- Cart helpers ----------
function readCart(){
  try{
    const raw = localStorage.getItem(STORE_KEY);
    return raw ? JSON.parse(raw) : [];
  }catch{ return []; }
}
function writeCart(items){
  localStorage.setItem(STORE_KEY, JSON.stringify(items));
}
function cartCount(){
  return readCart().reduce((sum, it) => sum + (it.qty || 0), 0);
}
function setBadges(){
  const c = cartCount();
  const cartCountEl = document.getElementById("cartCount");
  if(cartCountEl) cartCountEl.textContent = String(c);
}
function addToCart(id, qty=1, opts={}){
  const items = readCart();
  const existing = items.find(x => x.id === id && x.size === (opts.size||""));
  if(existing) existing.qty += qty;
  else items.push({id, qty, size: opts.size || ""});
  writeCart(items);
  setBadges();
setWishBadge();
syncHearts();
}

// ---------- Header drawer ----------
const drawer = document.getElementById('drawer');
const menuBtn = document.getElementById('menuBtn');
const closeMenu = document.getElementById('closeMenu');
const drawerBg = document.getElementById('drawerBg');
function openMenu(){
  if(!drawer) return;
  drawer.setAttribute('aria-hidden','false');
  document.body.style.overflow = 'hidden';
}
function closeMenuFn(){
  if(!drawer) return;
  drawer.setAttribute('aria-hidden','true');
  document.body.style.overflow = '';
}
menuBtn?.addEventListener('click', openMenu);
closeMenu?.addEventListener('click', closeMenuFn);
drawerBg?.addEventListener('click', closeMenuFn);
drawer?.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenuFn));

// ---------- Render product grids ----------
function zoomSvg(){
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 3a7 7 0 1 0 4.3 12.5l4.1 4.1 1.4-1.4-4.1-4.1A7 7 0 0 0 10 3Zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm1 1h-2v3H6v2h3v3h2v-3h3V9h-3V6Z"/></svg>`;
}
function productCard(p){
  const price = p.sale ? `<span class="strike">${money(p.was)}</span>${money(p.price)}` : money(p.price);
  const salePill = p.sale ? `<div class="salePill">Sale</div>` : ``;
  const desc = p.desc ? `<div class="productDesc">${p.desc}</div>` : ``;

  return `
    <article class="productCard">
      <a class="productLink" href="product.html?id=${encodeURIComponent(p.id)}" aria-label="${p.name}">
        <div class="productImg">
          ${salePill}
          <img class="productPhoto" src="${p.img}" alt="${p.name}">
          <div class="productZoom" title="Quick view">${zoomSvg()}</div>
          <button class="heartBtn" type="button" data-save="${p.id}" aria-label="Save item">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-4.5-9.4-8.6C.7 9 .9 6.5 2.8 4.8 4.5 3.3 7.2 3.4 9 5.1c1 .9 1.5 2 1.5 2s.5-1.1 1.5-2c1.8-1.7 4.5-1.8 6.2-.3 1.9 1.7 2.1 4.2.2 7.6C19 16.5 12 21 12 21Z"/></svg>
          </button>
        </div>
        <div class="productTitle">${p.name}</div>
        ${desc}
        <div class="productPrice">${price}</div>
      </a>
      <button class="productBtn" type="button" data-add="${p.id}">Add to Basket</button>
    </article>
  `;
}
function renderGrid(gridId, list){
  const grid = document.getElementById(gridId);
  if(!grid) return;
  grid.innerHTML = list.map(productCard).join('');
}

const page = document.documentElement.getAttribute("data-page") || "";
if(page === "home"){
  renderGrid("productGrid", PRODUCTS.slice(0,8));
}
if(page === "sales"){
  renderGrid("salesGrid", PRODUCTS.filter(p => p.sale));
}
if(page === "women"){
  renderGrid("womenGrid", PRODUCTS.filter(p => p.category === "women"));
}
if(page === "kids"){
  renderGrid("kidsGrid", PRODUCTS.filter(p => p.category === "kids"));
}
if(page === "babies"){
  renderGrid("babiesGrid", PRODUCTS.filter(p => p.category === "babies"));
}

// Add-to-cart buttons on grids
document.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-add]");
  if(!btn) return;
  const id = btn.getAttribute("data-add");
  addToCart(id, 1, {size:""});
});

// ---------- Product page ----------
function getQuery(name){
  const u = new URL(window.location.href);
  return u.searchParams.get(name);
}
if(page === "product"){
  const id = getQuery("id");
  const p = PRODUCTS.find(x => x.id === id) || PRODUCTS[0];
  const img = document.getElementById("prodImg");
  const title = document.getElementById("prodTitle");
  const price = document.getElementById("prodPrice");
  const sub = document.getElementById("prodSub");
  const sizeSel = document.getElementById("sizeSel");
  const qtyInput = document.getElementById("qtyInput");
  const addBtn = document.getElementById("addBig");

  if(img) img.style.backgroundImage = `url('${p.img}')`;
  if(title) title.textContent = p.name;
  if(sub) sub.textContent = (p.category || "").toUpperCase() + " • Premium boutique preview";
  if(price){
    price.innerHTML = p.sale ? `<span class="strike">${money(p.was)}</span>${money(p.price)}` : money(p.price);
  }

  addBtn?.addEventListener("click", () => {
    const qty = Math.max(1, parseInt(qtyInput?.value || "1", 10));
    const size = sizeSel?.value || "";
    addToCart(p.id, qty, {size});
    alert("Added to basket (demo).");
  });

  // You may also like
  const rec = document.getElementById("recGrid");
  if(rec){
    const picks = PRODUCTS.filter(x => x.id !== p.id).slice(0,4);
    rec.innerHTML = picks.map(productCard).join('');
  }
}

// ---------- Cart page ----------
if(page === "cart"){
  const box = document.getElementById("cartBox");
  const totalEl = document.getElementById("cartTotal");
  const clearBtn = document.getElementById("clearCart");

  function renderCart(){
    const items = readCart();
    if(!box) return;

    if(items.length === 0){
      box.innerHTML = `<div class="cartMeta">Your basket is empty (demo).</div>`;
      if(totalEl) totalEl.textContent = money(0);
      return;
    }

    let total = 0;
    const rows = items.map(it => {
      const p = PRODUCTS.find(x => x.id === it.id);
      if(!p) return "";
      const line = p.price * (it.qty || 0);
      total += line;
      const sizeText = it.size ? `Size: ${it.size}` : `Size: —`;
      return `
        <div class="cartRow">
          <div class="cartThumb" style="background-image:url('${p.img}')"></div>
          <div>
            <div class="cartName">${p.name}</div>
            <div class="cartMeta">${sizeText} • Qty: ${it.qty}</div>
          </div>
          <div class="cartPrice">${money(line)}</div>
        </div>
      `;
    }).join("");

    box.innerHTML = rows;
    if(totalEl) totalEl.textContent = money(total);
  }

  clearBtn?.addEventListener("click", () => {
    writeCart([]);
    setBadges();
setWishBadge();
syncHearts();
    renderCart();
  });

  renderCart();
}

// ---------- Hero slider ----------
function initHero(){
  const slides = Array.from(document.querySelectorAll(".hero__slide"));
  const dots = Array.from(document.querySelectorAll(".hero__dots .dot"));
  if(slides.length === 0) return;

  let i = 0;
  function show(n){
    i = (n + slides.length) % slides.length;
    slides.forEach((s, idx) => s.classList.toggle("isActive", idx === i));
    dots.forEach((d, idx) => d.classList.toggle("dot--active", idx === i));
  }
  dots.forEach((d, idx) => d.addEventListener("click", () => show(idx)));
  show(0);

  setInterval(() => show(i+1), 4500);
}
initHero();

// Set badges on load
setBadges();
setWishBadge();
syncHearts();



// ============================
// Account / Orders / Saved items (DEMO)
// NOTE: This is front-end only (localStorage). Real store platforms handle accounts securely.
// ============================
const USERS_KEY = "myaimi_users_v1";
const SESSION_KEY = "myaimi_session_v1";
const ORDERS_KEY = "myaimi_orders_v1";
const SAVED_KEY = "myaimi_saved_v1";

function readJSON(key, fallback){
  try{ const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }catch{ return fallback; }
}
function writeJSON(key, val){ localStorage.setItem(key, JSON.stringify(val)); }

function getSession(){ return readJSON(SESSION_KEY, null); }
function setSession(sess){ writeJSON(SESSION_KEY, sess); }

function getSaved(email){
  const all = readJSON(SAVED_KEY, {});
  return all[email] || [];
}
function setSaved(email, arr){
  const all = readJSON(SAVED_KEY, {});
  all[email] = arr;
  writeJSON(SAVED_KEY, all);
}

function getOrders(email){
  const all = readJSON(ORDERS_KEY, {});
  return all[email] || [];
}
function setOrders(email, arr){
  const all = readJSON(ORDERS_KEY, {});
  all[email] = arr;
  writeJSON(ORDERS_KEY, all);
}

function ensureSignedIn(){
  const sess = getSession();
  if(!sess) return null;
  return sess;
}

// Create demo order from cart
function createOrderFromCart(){
  const sess = getSession();
  if(!sess) return {ok:false, reason:"no_session"};

  const cart = readCart();
  if(!cart || cart.length === 0) return {ok:false, reason:"empty_cart"};

  const id = "MC-" + Math.floor(100000 + Math.random()*900000);
  const now = new Date().toISOString();
  const lines = cart.map(it => {
    const p = PRODUCTS.find(x => x.id === it.id);
    return {id: it.id, name: p?.name || it.id, qty: it.qty || 1, price: p?.price || 0, img: p?.img || ""};
  });
  const total = lines.reduce((s,l)=>s + l.price*l.qty, 0);
  const order = {
    id,
    created_at: now,
    status: "Processing",
    steps: [
      {label:"Order placed", done:true, at: now},
      {label:"Processing", done:true, at: now},
      {label:"Dispatched", done:false, at: ""},
      {label:"Out for delivery", done:false, at: ""},
      {label:"Delivered", done:false, at: ""},
    ],
    lines,
    total
  };

  const orders = getOrders(sess.email);
  orders.unshift(order);
  setOrders(sess.email, orders);

  // Clear cart after checkout
  writeCart([]);
  setBadges();
setWishBadge();
syncHearts();

  return {ok:true, order};
}

// Wire checkout button
const checkoutBtn = document.getElementById("checkoutBtn");
checkoutBtn?.addEventListener("click", () => {
  const sess = getSession();
  if(!sess){
    alert("Please create an account / sign in to checkout (demo).");
    window.location.href = "account.html";
    return;
  }
  const res = createOrderFromCart();
  if(!res.ok){
    alert(res.reason === "empty_cart" ? "Your basket is empty." : "Please sign in.");
    return;
  }
  alert("Order created (demo): " + res.order.id);
  window.location.href = "account.html";
});

// Save to wishlist from product page
const saveItemBtn = document.getElementById("saveItemBtn");
if(saveItemBtn){
  saveItemBtn.addEventListener("click", () => {
    const u = new URL(window.location.href);
    const pid = u.searchParams.get("id");
    if(!pid) return;
    toggleSave(pid);
    alert("Saved / unsaved (demo).");
  });
}

// Account page UI
const authGrid = document.getElementById("authGrid");
const dash = document.getElementById("dash");

function showDashboard(sess){
  if(authGrid) authGrid.hidden = true

  if(dash) dash.hidden = false;

  const hello = document.getElementById("dashHello");
  const emailEl = document.getElementById("dashEmail");
  if(hello) hello.textContent = "Hello, " + (sess.name || "Customer");
  if(emailEl) emailEl.textContent = sess.email;

  // Details
  const detName = document.getElementById("detName");
  const detEmail = document.getElementById("detEmail");
  if(detName) detName.value = sess.name || "";
  if(detEmail) detEmail.value = sess.email || "";

  // Orders list
  renderOrdersList(sess.email);

  // Saved grid
  renderSaved(sess.email);
}

function showAuth(){
  if(authGrid) authGrid.hidden = false;
  if(dash) dash.hidden = true;
}

function renderOrdersList(email){
  const list = document.getElementById("ordersList");
  if(!list) return;
  const orders = getOrders(email);
  if(orders.length === 0){
    list.innerHTML = `<div class="cartMeta">No orders yet.</div>`;
    return;
  }
  list.innerHTML = orders.map(o => {
    const date = new Date(o.created_at).toLocaleString();
    return `
      <div class="orderRow">
        <div>
          <div class="cartName">${o.id}</div>
          <div class="cartMeta">${date} • ${o.status}</div>
        </div>
        <a class="smallBtn" href="account.html#track=${o.id}" data-track="${o.id}">Track</a>
      </div>
    `;
  }).join("");
}

function renderTracking(email, orderId){
  const box = document.getElementById("trackResult");
  if(!box) return;
  const orders = getOrders(email);
  const order = orders.find(o => o.id === orderId);
  if(!order){
    box.innerHTML = `<div class="cartMeta">Order not found.</div>`;
    return;
  }
  const steps = order.steps.map(s => {
    const cls = s.done ? "step step--done" : "step";
    return `<div class="${cls}"><span class="stepDot"></span><div><div class="cartName">${s.label}</div><div class="cartMeta">${s.at ? new Date(s.at).toLocaleString() : ""}</div></div></div>`;
  }).join("");
  box.innerHTML = `
    <div class="card" style="margin:0">
      <h3 style="margin:0 0 8px">Tracking: ${order.id}</h3>
      <div class="cartMeta" style="margin-bottom:10px">Status: ${order.status}</div>
      <div class="steps">${steps}</div>
    </div>
  `;
}

function renderSaved(email){
  const grid = document.getElementById("savedGrid");
  if(!grid) return;
  const saved = email ? getSaved(email) : getSavedForCurrent();
  if(saved.length === 0){
    grid.innerHTML = `<div class="cartMeta">No saved items yet.</div>`;
    return;
  }
  const list = saved.map(id => PRODUCTS.find(p => p.id === id)).filter(Boolean);
  grid.innerHTML = list.map(productCard).join("");
}

// Tabs
function initAccountTabs(){
  const btns = Array.from(document.querySelectorAll(".tabBtn"));
  const panels = {
    orders: document.getElementById("tab-orders"),
    tracking: document.getElementById("tab-tracking"),
    saved: document.getElementById("tab-saved"),
    details: document.getElementById("tab-details"),
  };
  function show(name){
    btns.forEach(b => b.classList.toggle("isActive", b.dataset.tab === name));
    Object.entries(panels).forEach(([k, el]) => el && el.classList.toggle("isActive", k === name));
  }
  btns.forEach(b => b.addEventListener("click", () => show(b.dataset.tab)));
  return {show};
}

const tabAPI = initAccountTabs();

// Account forms
const registerForm = document.getElementById("registerForm");
const loginForm = document.getElementById("loginForm");
const logoutBtn = document.getElementById("logoutBtn");

registerForm?.addEventListener("submit", (e) => {
  e.preventDefault();
  const name = (document.getElementById("regName")||{}).value || "";
  const email = (document.getElementById("regEmail")||{}).value || "";
  const pass = (document.getElementById("regPass")||{}).value || "";
  const users = readJSON(USERS_KEY, []);
  if(users.find(u => u.email === email)){
    alert("Account already exists. Please sign in.");
    return;
  }
  users.push({name, email, pass});
  writeJSON(USERS_KEY, users);
  setSession({name, email});
  alert("Account created (demo).");
  showDashboard({name, email});
});

loginForm?.addEventListener("submit", (e) => {
  e.preventDefault();
  const email = (document.getElementById("loginEmail")||{}).value || "";
  const pass = (document.getElementById("loginPass")||{}).value || "";
  const users = readJSON(USERS_KEY, []);
  const u = users.find(x => x.email === email && x.pass === pass);
  if(!u){
    alert("Wrong email/password (demo).");
    return;
  }
  setSession({name:u.name, email:u.email});
  showDashboard({name:u.name, email:u.email});
});

logoutBtn?.addEventListener("click", () => {
  localStorage.removeItem(SESSION_KEY);
  showAuth();
});

// Save details
document.getElementById("saveDetails")?.addEventListener("click", () => {
  const sess = getSession();
  if(!sess) return;
  const name = (document.getElementById("detName")||{}).value || "";
  // update users list
  const users = readJSON(USERS_KEY, []);
  const u = users.find(x => x.email === sess.email);
  if(u) u.name = name;
  writeJSON(USERS_KEY, users);
  setSession({name, email:sess.email});
  alert("Saved (demo).");
  showDashboard({name, email:sess.email});
});

// Tracking form
document.getElementById("trackForm")?.addEventListener("submit", (e) => {
  e.preventDefault();
  const sess = getSession();
  if(!sess){ alert("Please sign in."); return; }
  const id = (document.getElementById("trackId")||{}).value || "";
  tabAPI?.show("tracking");
  renderTracking(sess.email, id.trim());
});

// Deep-link tracking from hash
function parseHashTrack(){
  const h = window.location.hash || "";
  const m = h.match(/track=([A-Z0-9\-]+)/);
  return m ? m[1] : "";
}

if(document.documentElement.getAttribute("data-page") === "account"){
  const sess = getSession();
  if(sess){
    showDashboard(sess);
    const trackId = parseHashTrack();
    if(trackId){
      tabAPI?.show("tracking");
      const inp = document.getElementById("trackId");
      if(inp) inp.value = trackId;
      renderTracking(sess.email, trackId);
    }
  }else{
    showAuth();
  }
}


// ---------- Saved / Like (wishlist) ----------
function currentUserEmail(){
  const sess = getSession?.() || null;
  return sess && sess.email ? sess.email : "";
}
function getSavedForCurrent(){
  const email = currentUserEmail();
  if(email){
    return getSaved(email);
  }
  // guest saved
  return readJSON("myaimi_saved_guest_v1", []);
}
function setSavedForCurrent(arr){
  const email = currentUserEmail();
  if(email){
    setSaved(email, arr);
  }else{
    writeJSON("myaimi_saved_guest_v1", arr);
  }
}
function setWishBadge(){
  const wishCountEl = document.getElementById("wishCount");
  if(!wishCountEl) return;
  wishCountEl.textContent = String(getSavedForCurrent().length);
}
function toggleSave(id){
  const saved = getSavedForCurrent();
  const idx = saved.indexOf(id);
  if(idx >= 0) saved.splice(idx,1);
  else saved.unshift(id);
  setSavedForCurrent(saved);
  setWishBadge();
  // update any heart buttons for this id
  document.querySelectorAll(`[data-save="${id}"]`).forEach(btn => {
    btn.classList.toggle("isSaved", saved.includes(id));
  });
}
document.addEventListener("click", (e) => {
  const hb = e.target.closest("[data-save]");
  if(!hb) return;
  e.preventDefault();
  e.stopPropagation();
  const id = hb.getAttribute("data-save");
  toggleSave(id);
});

// Sync heart states when grids render
function syncHearts(){
  const saved = getSavedForCurrent();
  document.querySelectorAll("[data-save]").forEach(btn => {
    const id = btn.getAttribute("data-save");
    btn.classList.toggle("isSaved", saved.includes(id));
  });
}

// Open saved tab when visiting account.html#saved
if(document.documentElement.getAttribute("data-page") === "account"){
  const h = (window.location.hash || "").toLowerCase();
  if(h.includes("saved")){
    tabAPI?.show("saved");
  }
}

// ---------- Admin (demo) ----------
const ADMIN_SESSION_KEY = "myaimi_admin_session_v1";
function isAdmin(){ return readJSON(ADMIN_SESSION_KEY, false) === true; }
function setAdmin(on){ writeJSON(ADMIN_SESSION_KEY, !!on); }

function renderAdminTable(){
  const table = document.getElementById("prodTable");
  if(!table) return;
  const rows = PRODUCTS.map(p => `
    <tr>
      <td><strong>${p.id}</strong></td>
      <td>${p.name}<div class="mini">${p.category.toUpperCase()} • ${money(p.price)}</div></td>
      <td><button class="smallBtn" type="button" data-edit="${p.id}">Edit</button></td>
    </tr>
  `).join("");
  table.innerHTML = `
    <tr><th>ID</th><th>Product</th><th></th></tr>
    ${rows}
  `;
}

function fillAdminForm(p){
  (document.getElementById("pId")||{}).value = p.id || "";
  (document.getElementById("pName")||{}).value = p.name || "";
  (document.getElementById("pDesc")||{}).value = p.desc || "";
  (document.getElementById("pPrice")||{}).value = p.price != null ? String(p.price) : "";
  (document.getElementById("pCat")||{}).value = p.category || "women";
  (document.getElementById("pImg")||{}).value = p.img || "assets/p1.jpg";
  (document.getElementById("pSale")||{}).checked = !!p.sale;
  (document.getElementById("pWas")||{}).value = p.was != null ? String(p.was) : "";
}

function saveProductsCustom(list){
  writeJSON(PRODUCTS_KEY, list);
  PRODUCTS = loadProducts();
  PRODUCTS = PRODUCTS.map(p => ({...p, desc: p.desc || "Boutique essential"}));
}

if(document.documentElement.getAttribute("data-page") === "admin"){
  const auth = document.getElementById("adminAuth");
  const panel = document.getElementById("adminPanel");
  const login = document.getElementById("adminLogin");

  function showAdmin(){
    if(auth) auth.hidden = true;
    if(panel) panel.hidden = false;
    renderAdminTable();
    fillAdminForm(PRODUCTS[0] || {});
  }
  function showAuth(){
    if(auth) auth.hidden = false;
    if(panel) panel.hidden = true;
  }

  if(isAdmin()) showAdmin(); else showAuth();

  login?.addEventListener("submit", (e)=>{
    e.preventDefault();
    const u = (document.getElementById("adminUser")||{}).value || "";
    const p = (document.getElementById("adminPass")||{}).value || "";
    if(u === "admin" && p === "admin123"){
      setAdmin(true);
      showAdmin();
    }else{
      alert("Wrong admin login (demo).");
    }
  });

  document.getElementById("logoutAdmin")?.addEventListener("click", ()=>{
    setAdmin(false);
    showAuth();
  });

  document.addEventListener("click", (e)=>{
    const b = e.target.closest("[data-edit]");
    if(!b) return;
    const id = b.getAttribute("data-edit");
    const p = PRODUCTS.find(x=>x.id===id);
    if(p) fillAdminForm(p);
  });

  document.getElementById("saveProd")?.addEventListener("click", ()=>{
    const id = (document.getElementById("pId")||{}).value.trim();
    const name = (document.getElementById("pName")||{}).value.trim();
    const desc = (document.getElementById("pDesc")||{}).value.trim();
    const price = parseFloat((document.getElementById("pPrice")||{}).value || "0");
    const category = (document.getElementById("pCat")||{}).value;
    const img = (document.getElementById("pImg")||{}).value;
    const sale = !!(document.getElementById("pSale")||{}).checked;
    const wasRaw = (document.getElementById("pWas")||{}).value.trim();
    const was = wasRaw ? parseFloat(wasRaw) : undefined;

    if(!id || !name){ alert("Please add ID + Name."); return; }

    const list = loadProducts();
    const idx = list.findIndex(x=>x.id===id);
    const obj = {id, name, desc, price, img, category, tags:[], sale, was};
    if(idx>=0) list[idx] = {...list[idx], ...obj};
    else list.unshift(obj);
    saveProductsCustom(list);
    PRODUCTS = loadProducts();
    renderAdminTable();
    alert("Saved (demo). Refresh other pages to see changes.");
  });

  document.getElementById("deleteProd")?.addEventListener("click", ()=>{
    const id = (document.getElementById("pId")||{}).value.trim();
    if(!id) return;
    const list = loadProducts().filter(x=>x.id!==id);
    saveProductsCustom(list);
    PRODUCTS = loadProducts();
    renderAdminTable();
    alert("Deleted (demo).");
  });

  document.getElementById("seedBtn")?.addEventListener("click", ()=>{
    localStorage.removeItem(PRODUCTS_KEY);
    PRODUCTS = loadProducts();
    renderAdminTable();
    alert("Reset to demo products.");
  });
}
