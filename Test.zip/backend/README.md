# Myaimi Collective — Pro Backend (Custom)

This backend adds:
- Secure accounts (hashed passwords + httpOnly cookie session)
- Admin APIs (products/stock/images/orders/users)
- Stripe Checkout payments
- Orders stored in database + status tracking
- Image uploads (up to 6 images per product)

## Run locally
1) Install Node 18+
2) `cd backend && npm i`
3) `cp .env.example .env`
4) `docker compose up -d`
5) `npm run prisma:migrate`
6) `npm run dev`

## Create an admin user
```bash
node --env-file=.env src/scripts/createAdmin.js admin@myaimi.com admin123
```

## Production must-haves
- HTTPS
- Strong JWT_SECRET
- Stripe webhook configured
- Use S3/Cloudinary for uploads (recommended)
