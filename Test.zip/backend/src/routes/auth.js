import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { hashPassword, verifyPassword, signSession } from "../lib/auth.js";
import { env } from "../lib/env.js";
import { validate } from "../middleware/validate.js";
import { requireAuth } from "../middleware/requireAuth.js";

export const authRouter = Router();

authRouter.post("/register", validate(z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(1).max(120).optional(),
})), async (req,res)=>{
  const { email, password, name } = req.body;
  const existing = await prisma.user.findUnique({ where: { email } });
  if(existing) return res.status(409).json({ error:"EMAIL_IN_USE" });

  const passwordHash = await hashPassword(password);
  const user = await prisma.user.create({ data: { email, passwordHash, name: name || null } });

  const token = signSession({ uid: user.id });
  res.cookie(env.COOKIE_NAME, token, {
    httpOnly:true, sameSite:"lax",
    secure: env.COOKIE_SECURE || env.NODE_ENV==="production",
    domain: env.COOKIE_DOMAIN || undefined,
    path:"/",
    maxAge: 7*24*60*60*1000
  });
  res.json({ ok:true, user:{ id:user.id, email:user.email, name:user.name, role:user.role } });
});

authRouter.post("/login", validate(z.object({
  email: z.string().email(),
  password: z.string().min(1),
})), async (req,res)=>{
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  if(!user) return res.status(401).json({ error:"BAD_CREDENTIALS" });

  const ok = await verifyPassword(password, user.passwordHash);
  if(!ok) return res.status(401).json({ error:"BAD_CREDENTIALS" });

  const token = signSession({ uid: user.id });
  res.cookie(env.COOKIE_NAME, token, {
    httpOnly:true, sameSite:"lax",
    secure: env.COOKIE_SECURE || env.NODE_ENV==="production",
    domain: env.COOKIE_DOMAIN || undefined,
    path:"/",
    maxAge: 7*24*60*60*1000
  });
  res.json({ ok:true, user:{ id:user.id, email:user.email, name:user.name, role:user.role } });
});

authRouter.post("/logout", async (req,res)=>{
  res.clearCookie(env.COOKIE_NAME, { path:"/" });
  res.json({ ok:true });
});

authRouter.get("/me", requireAuth, async (req,res)=>{
  res.json({ ok:true, user:req.user });
});
