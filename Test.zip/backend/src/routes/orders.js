import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/requireAuth.js";

export const ordersRouter = Router();

ordersRouter.get("/", requireAuth, async (req,res)=>{
  const orders = await prisma.order.findMany({
    where: { userId: req.user.id },
    include: { items: true },
    orderBy: { createdAt:"desc" }
  });
  res.json({ ok:true, orders });
});
