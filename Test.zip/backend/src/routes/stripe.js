import { Router } from "express";
import Stripe from "stripe";
import { env } from "../lib/env.js";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/requireAuth.js";

export const stripeRouter = Router();
const stripe = new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" });

stripeRouter.post("/create-checkout-session", requireAuth, async (req,res)=>{
  const { items } = req.body || {};
  if(!Array.isArray(items) || items.length===0) return res.status(400).json({ error:"EMPTY_CART" });

  const ids = items.map(i => i.productId);
  const products = await prisma.product.findMany({ where:{ id:{ in: ids }, isActive:true } });
  const map = new Map(products.map(p => [p.id, p]));

  const line_items = items.map(i => {
    const p = map.get(i.productId);
    if(!p) throw new Error("Invalid product");
    return {
      price_data: {
        currency: env.STRIPE_CURRENCY,
        product_data: { name: p.title },
        unit_amount: p.pricePence
      },
      quantity: Math.max(1, Math.min(99, parseInt(i.qty || 1, 10)))
    };
  });

  const subtotal = line_items.reduce((s, li) => s + li.price_data.unit_amount * li.quantity, 0);

  const order = await prisma.order.create({
    data:{
      userId: req.user.id,
      email: req.user.email,
      status:"PENDING",
      subtotalPence: subtotal,
      shippingPence: 0,
      totalPence: subtotal,
      items: { create: items.map(i => {
        const p = map.get(i.productId);
        return {
          productId: p.id,
          title: p.title,
          unitPricePence: p.pricePence,
          qty: Math.max(1, Math.min(99, parseInt(i.qty || 1, 10))),
          size: i.size || null
        };
      })}
    }
  });

  const session = await stripe.checkout.sessions.create({
    mode:"payment",
    customer_email: req.user.email,
    line_items,
    success_url: `${env.FRONTEND_ORIGIN}/order-success.html?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${env.FRONTEND_ORIGIN}/cart.html`,
    metadata: { orderId: order.id }
  });

  await prisma.order.update({ where:{ id: order.id }, data:{ stripeSessionId: session.id } });
  res.json({ ok:true, url: session.url });
});

stripeRouter.post("/webhook", async (req,res)=>{
  const sig = req.headers["stripe-signature"];
  let event;
  try{
    event = stripe.webhooks.constructEvent(req.rawBody, sig, env.STRIPE_WEBHOOK_SECRET);
  }catch(err){
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if(event.type === "checkout.session.completed"){
    const session = event.data.object;
    const orderId = session.metadata?.orderId;
    if(orderId){
      await prisma.order.updateMany({
        where:{ id: orderId, stripeSessionId: session.id },
        data:{ status:"PAID" }
      });
    }
  }
  res.json({ received:true });
});
