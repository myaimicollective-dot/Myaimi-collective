import { Router } from "express";
import { z } from "zod";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/requireAuth.js";
import { requireAdmin } from "../middleware/requireAdmin.js";
import { validate } from "../middleware/validate.js";

export const adminRouter = Router();
adminRouter.use(requireAuth, requireAdmin);

adminRouter.get("/users", async (req,res)=>{
  const users = await prisma.user.findMany({ select:{ id:true, email:true, name:true, role:true, createdAt:true } });
  res.json({ ok:true, users });
});

adminRouter.get("/orders", async (req,res)=>{
  const orders = await prisma.order.findMany({ include:{ items:true, user:true }, orderBy:{ createdAt:"desc" } });
  res.json({ ok:true, orders });
});

adminRouter.put("/orders/:id/status", validate(z.object({
  status: z.enum(["PENDING","PAID","PROCESSING","DISPATCHED","OUT_FOR_DELIVERY","DELIVERED","CANCELLED","REFUNDED"])
})), async (req,res)=>{
  const order = await prisma.order.update({ where:{ id:req.params.id }, data:{ status:req.body.status } });
  res.json({ ok:true, order });
});

adminRouter.get("/products", async (req,res)=>{
  const products = await prisma.product.findMany({
    include:{ images:{ orderBy:{ sort:"asc" } }, sizes:true },
    orderBy:{ updatedAt:"desc" }
  });
  res.json({ ok:true, products });
});

adminRouter.post("/products", validate(z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  category: z.string().min(1),
  pricePence: z.number().int().nonnegative(),
  wasPricePence: z.number().int().nonnegative().optional(),
  stock: z.number().int().nonnegative(),
  sizes: z.array(z.string().min(1)).optional()
})), async (req,res)=>{
  const { title, description, category, pricePence, wasPricePence, stock, sizes } = req.body;
  const product = await prisma.product.create({
    data:{
      title, description, category, pricePence, wasPricePence: wasPricePence ?? null, stock,
      sizes: sizes?.length ? { create: sizes.map(l => ({ label:l, inStock:true })) } : undefined
    }
  });
  res.json({ ok:true, product });
});

adminRouter.put("/products/:id", validate(z.object({
  title: z.string().min(1).optional(),
  description: z.string().min(1).optional(),
  category: z.string().min(1).optional(),
  pricePence: z.number().int().nonnegative().optional(),
  wasPricePence: z.number().int().nonnegative().optional().nullable(),
  stock: z.number().int().nonnegative().optional(),
  isActive: z.boolean().optional(),
  sizes: z.array(z.string().min(1)).optional()
})), async (req,res)=>{
  const id = req.params.id;
  const { sizes, ...data } = req.body;
  const updated = await prisma.product.update({ where:{ id }, data });
  if(sizes){
    await prisma.productSize.deleteMany({ where:{ productId:id } });
    await prisma.productSize.createMany({ data: sizes.map(l => ({ productId:id, label:l, inStock:true })) });
  }
  res.json({ ok:true, product: updated });
});

adminRouter.delete("/products/:id", async (req,res)=>{
  await prisma.product.delete({ where:{ id:req.params.id } });
  res.json({ ok:true });
});

// Uploads
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadDir = path.resolve(__dirname, "../../uploads");

const storage = multer.diskStorage({
  destination: (req,file,cb)=>cb(null, uploadDir),
  filename: (req,file,cb)=>{
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_");
    cb(null, `${Date.now()}_${safe}`);
  }
});

const upload = multer({
  storage,
  limits:{ fileSize: 8*1024*1024 },
  fileFilter:(req,file,cb)=>{
    const ok = ["image/jpeg","image/png","image/webp"].includes(file.mimetype);
    cb(ok ? null : new Error("Only jpg/png/webp"), ok);
  }
});

adminRouter.post("/products/:id/images", upload.array("images", 6), async (req,res)=>{
  const id = req.params.id;
  const files = req.files || [];
  const baseUrl = "/uploads/";
  const existingCount = await prisma.productImage.count({ where:{ productId:id } });
  await prisma.productImage.createMany({
    data: files.map((f, idx) => ({ productId:id, url: baseUrl + f.filename, sort: existingCount + idx }))
  });
  res.json({ ok:true, added: files.length });
});
