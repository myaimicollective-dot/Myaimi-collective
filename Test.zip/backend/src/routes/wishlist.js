import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/requireAuth.js";

export const wishlistRouter = Router();

wishlistRouter.get("/", requireAuth, async (req,res)=>{
  const items = await prisma.wishlistItem.findMany({
    where: { userId: req.user.id },
    include: { product: { include: { images: { orderBy: { sort:"asc" } } } } },
    orderBy: { createdAt:"desc" }
  });
  res.json({ ok:true, items: items.map(it => ({
    productId: it.productId,
    title: it.product.title,
    image: it.product.images[0]?.url || "",
    pricePence: it.product.pricePence
  }))});
});

wishlistRouter.post("/:productId/toggle", requireAuth, async (req,res)=>{
  const productId = req.params.productId;
  const existing = await prisma.wishlistItem.findUnique({
    where: { userId_productId: { userId: req.user.id, productId } }
  });
  if(existing){
    await prisma.wishlistItem.delete({ where: { id: existing.id } });
    return res.json({ ok:true, saved:false });
  }
  await prisma.wishlistItem.create({ data: { userId: req.user.id, productId } });
  res.json({ ok:true, saved:true });
});
