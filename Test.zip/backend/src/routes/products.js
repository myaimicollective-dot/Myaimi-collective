import { Router } from "express";
import { prisma } from "../lib/prisma.js";

export const productsRouter = Router();

productsRouter.get("/", async (req,res)=>{
  const category = (req.query.category || "").toString();
  const where = { isActive: true };
  if(category) where.category = category;

  const products = await prisma.product.findMany({
    where,
    include: { images: { orderBy: { sort:"asc" } }, sizes: true },
    orderBy: { updatedAt:"desc" }
  });
  res.json({ ok:true, products: products.map(p => ({
    id: p.id,
    title: p.title,
    description: p.description,
    category: p.category,
    pricePence: p.pricePence,
    wasPricePence: p.wasPricePence,
    stock: p.stock,
    images: p.images.map(i => i.url),
    sizes: p.sizes.map(s => ({ label:s.label, inStock:s.inStock })),
  }))});
});

productsRouter.get("/:id", async (req,res)=>{
  const p = await prisma.product.findUnique({
    where: { id: req.params.id },
    include: { images: { orderBy: { sort:"asc" } }, sizes: true }
  });
  if(!p || !p.isActive) return res.status(404).json({ error:"NOT_FOUND" });
  res.json({ ok:true, product: {
    id: p.id,
    title: p.title,
    description: p.description,
    category: p.category,
    pricePence: p.pricePence,
    wasPricePence: p.wasPricePence,
    stock: p.stock,
    images: p.images.map(i => i.url),
    sizes: p.sizes.map(s => ({ label:s.label, inStock:s.inStock })),
  }});
});
