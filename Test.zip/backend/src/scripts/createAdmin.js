import { prisma } from "../lib/prisma.js";
import { hashPassword } from "../lib/auth.js";

const [,, email, password] = process.argv;
if(!email || !password){
  console.log("Usage: node --env-file=.env src/scripts/createAdmin.js <email> <password>");
  process.exit(1);
}

const existing = await prisma.user.findUnique({ where: { email } });
if(existing){
  await prisma.user.update({ where:{ email }, data:{ role:"ADMIN" } });
  console.log("Updated to ADMIN:", email);
  process.exit(0);
}

const passwordHash = await hashPassword(password);
await prisma.user.create({ data:{ email, passwordHash, role:"ADMIN", name:"Admin" } });
console.log("Created admin:", email);
