import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import path from "path";
import { fileURLToPath } from "url";

import { env } from "./lib/env.js";
import { authRouter } from "./routes/auth.js";
import { productsRouter } from "./routes/products.js";
import { wishlistRouter } from "./routes/wishlist.js";
import { ordersRouter } from "./routes/orders.js";
import { adminRouter } from "./routes/admin.js";
import { stripeRouter } from "./routes/stripe.js";

const app = express();

// Stripe webhook needs raw body on that route only
app.use((req,res,next)=>{
  if(req.originalUrl === "/api/stripe/webhook"){
    let data = "";
    req.on("data", c => data += c);
    req.on("end", ()=>{ req.rawBody = data; next(); });
  }else next();
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: env.FRONTEND_ORIGIN ? [env.FRONTEND_ORIGIN] : true, credentials:true }));
app.use(rateLimit({ windowMs: 60_000, limit: 120 }));
app.use(cookieParser());
app.use(morgan("tiny"));
app.use(express.json({ limit:"1mb" }));

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use("/uploads", express.static(path.resolve(__dirname, "../uploads")));

app.get("/health", (req,res)=>res.json({ ok:true }));

app.use("/api/auth", authRouter);
app.use("/api/products", productsRouter);
app.use("/api/wishlist", wishlistRouter);
app.use("/api/orders", ordersRouter);
app.use("/api/admin", adminRouter);
app.use("/api/stripe", stripeRouter);

app.use((err, req, res, next)=>{
  console.error(err);
  res.status(500).json({ error:"SERVER_ERROR" });
});

app.listen(env.PORT, ()=> console.log(`Backend on :${env.PORT}`));
