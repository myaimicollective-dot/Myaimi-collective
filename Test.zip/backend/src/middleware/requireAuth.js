import { prisma } from "../lib/prisma.js";
import { verifySession } from "../lib/auth.js";
import { env } from "../lib/env.js";

export async function requireAuth(req,res,next){
  try{
    const token = req.cookies?.[env.COOKIE_NAME];
    if(!token) return res.status(401).json({ error:"UNAUTHENTICATED" });
    const payload = verifySession(token);
    const user = await prisma.user.findUnique({ where: { id: payload.uid } });
    if(!user) return res.status(401).json({ error:"UNAUTHENTICATED" });
    req.user = { id:user.id, email:user.email, role:user.role, name:user.name || "" };
    next();
  }catch{
    return res.status(401).json({ error:"UNAUTHENTICATED" });
  }
}
